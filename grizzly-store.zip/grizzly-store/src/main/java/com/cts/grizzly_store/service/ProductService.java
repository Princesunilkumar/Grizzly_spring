package com.cts.grizzly_store.service;

import java.util.List;

import com.cts.grizzly_store.bean.Product;

public interface ProductService {

	public String insertProduct(Product product);
	public List<Product> getAllProduct();
	public List<Product> getAllProductbylowtohigh(String order);
	public String deleteProduct(String productId);
	public Product getProductById(String productId);
	public boolean block(String productId, String status);
	public List<Product> getProductForVendor();
	public String getProductStatus(String productId);
	public boolean unblock(String productId, String status);
	public List<Product> getProductForVendor1(String order);
}
