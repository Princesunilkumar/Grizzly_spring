package com.cts.grizzly_store.dao;

import java.util.List;

import com.cts.grizzly_store.bean.Product;



public interface ProductDAO {

	public String insertProduct(Product product);
	public String deleteProduct(String productId);
	public List<Product> getAllProduct();
	public Product getProductById(String productId);
	public List<Product> getAllProductbylowtohigh(String order);
	public boolean block(String productId, String status);
	public List<Product> getProductForVendor();
	public String getProductStatus(String productId);
	public boolean unblock(String productId, String status);
	public List<Product> getProductForVendor1(String order);
}
