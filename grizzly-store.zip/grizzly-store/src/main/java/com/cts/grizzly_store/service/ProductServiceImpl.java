package com.cts.grizzly_store.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzly_store.bean.Product;
import com.cts.grizzly_store.dao.ProductDAO;



@Service("productService")
@Transactional(propagation=Propagation.SUPPORTS)
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDAO productDAO;
	@Override
	public String insertProduct(Product product) {
		
		// TODO Auto-generated method stub
		return productDAO.insertProduct(product);
	}
	
	@Override
	public List<Product> getAllProduct(){
		return productDAO.getAllProduct();
		
	}
		@Override
		public List<Product> getAllProductbylowtohigh(String order){
			return productDAO.getAllProductbylowtohigh(order);
		}
		public String deleteProduct(String productId){
			return productDAO.deleteProduct(productId);
		}
		public Product getProductById(String productId)
		{
			return productDAO.getProductById(productId);
		}
		public boolean block(String productId, String status){
			return productDAO.block(productId,status);
		}
		public List<Product> getProductForVendor()
		{
			return productDAO.getProductForVendor();
		}
		public String getProductStatus(String productId){
			return productDAO.getProductStatus(productId);
		}
		public boolean unblock(String productId, String status)
		{
			return productDAO.unblock(productId,status);
		}
		public List<Product> getProductForVendor1(String order)
		{
			return productDAO.getProductForVendor1(order);
		}

}
