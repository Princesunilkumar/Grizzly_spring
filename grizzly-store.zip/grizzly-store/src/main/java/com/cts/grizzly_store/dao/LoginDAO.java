package com.cts.grizzly_store.dao;

import com.cts.grizzly_store.bean.Login;

public interface LoginDAO {


	public Login authenticate(String userName, String password);
	public String getUserType(String userId);
}
