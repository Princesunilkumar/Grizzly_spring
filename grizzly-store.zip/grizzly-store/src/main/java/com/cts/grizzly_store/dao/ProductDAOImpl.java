package com.cts.grizzly_store.dao;

import java.util.List;

import javax.persistence.EntityTransaction;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.type.TrueFalseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cts.grizzly_store.bean.Category;
import com.cts.grizzly_store.bean.Product;



@Repository("productDAO")
@Transactional

public class ProductDAOImpl implements ProductDAO {
	@Autowired

	 private SessionFactory sessionFacotry;

	@Transactional
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		Session session =null;
		String query="from Product";
		org.hibernate.query.Query<Product> query2 = null;
		session=sessionFacotry.openSession();
		query2=session.createQuery(query);
		List<Product> list=query2.getResultList();
		System.out.println(list);
		return list;
	}

	@Transactional
	public Product getProductById(String productId) {
		Session session =null;
		String query="from Product where productId=?";
		org.hibernate.query.Query<Product> query2 = null;
	Product product1= new Product();
		try {
			session = sessionFacotry.getCurrentSession();
			
			query2 = session.createQuery(query);
			query2.setParameter(0, productId);
			product1 = query2.getSingleResult();
			 //System.out.println("aa");
			 return product1;
			// TODO: handle exception
			
		}
		finally{
			
		}
	}
	
	
	@Transactional
	public String insertProduct(Product product) {
		
		Session session = null;
		
	
			session = sessionFacotry.getCurrentSession();

		session.save(product);
		product.setProductStatus("1");
		return "Success";

		}
		
		
	public List<Product> getAllProductbylowtohigh(String order) {
		// TODO Auto-generated method stub
		Session session =null;
		String query;
		if(order.equals("LowToHigh")){
		query="from Product order by productName asc";
		}
		else{
			 query="from Product order by productName desc";
		}
		org.hibernate.query.Query<Product> query2 = null;
		session=sessionFacotry.openSession();
		query2=session.createQuery(query);
		List<Product> list=query2.getResultList();
		System.out.println(list);
		return list;
	}
			
@Transactional
	public String deleteProduct(String productId) {
		
		Session session=null;
		//String query= "delete from Product where productId=?";
		session = sessionFacotry.getCurrentSession();
		try{
		Product object = new Product();
		object.setProductId(productId);
		session.delete(object);
		return "Success";
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return "failed";
		}
		
		
	}
@Transactional
public boolean block(String productId, String status)
{
	
Session session=null;
//	String query="update Product SET productStatus=2 where productId=?";

	session = sessionFacotry.getCurrentSession();
	Product product= session.get(Product.class, productId);
	if(status.equals("1")){
	product.setProductStatus("2");
	System.out.println(product);
//	org.hibernate.query.Query<String> query2 = null;
	session.saveOrUpdate(product);
	}
//	//query2.setParameter(0, productId);
//	//String s=query2.getSingleResult();
//	
////	Query query2 = null;
//	session.createQuery(query);
//	query2.setParameter(0, productId);
//	query2.executeUpdate();
//	System.out.println("aaaaaaaaaaaaaaaaaaaaaaaa");
	return true;
	
}
public List<Product> getProductForVendor()
{
	Session session =null;
	String query="from Product where productStatus='1' OR productStatus=NULL";
	org.hibernate.query.Query<Product> query2 = null;
	session=sessionFacotry.openSession();
	query2=session.createQuery(query);
	List<Product> list=query2.getResultList();
	System.out.println(list);
	return list;
}
public String getProductStatus(String productId)
{
	Session session =null;
	String query="select productStatus from Product where productId=?";
	org.hibernate.query.Query<String> query2 = null;
	try {
		session = sessionFacotry.getCurrentSession();
		
		query2 = session.createQuery(query);
		query2.setParameter(0, productId);
		 String s=query2.getSingleResult();
		return s;
		// TODO: handle exception
		
	}
	finally{
		
	}
}

public boolean unblock(String productId, String status){
	Session session=null;
//	String query="update Product SET productStatus=2 where productId=?";

	session = sessionFacotry.getCurrentSession();
	Product product= session.get(Product.class, productId);
	if(status.equals("2")){
	product.setProductStatus("1");
	System.out.println(product);
//	org.hibernate.query.Query<String> query2 = null;
	session.saveOrUpdate(product);
	}
//	//query2.setParameter(0, productId);
//	//String s=query2.getSingleResult();
//	
////	Query query2 = null;
//	session.createQuery(query);
//	query2.setParameter(0, productId);
//	query2.executeUpdate();
//	System.out.println("aaaaaaaaaaaaaaaaaaaaaaaa");
	return true;
	
}

public List<Product> getProductForVendor1(String order)
{
	Session session =null;
	String query;
	if(order.equals("LowToHigh")){
	query="from Product where productStatus='1' order by productName asc";
	}
	else{
		 query="from Product where productStatus='1' order by productName desc";
	}
	org.hibernate.query.Query<Product> query2 = null;
	session=sessionFacotry.openSession();
	query2=session.createQuery(query);
	List<Product> list=query2.getResultList();
	System.out.println(list);
	return list;
}
}
