package com.cts.grizzly_store.controller;

import java.util.List;

import javax.jws.WebParam.Mode;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cts.grizzly_store.bean.Category;
import com.cts.grizzly_store.bean.Login;
import com.cts.grizzly_store.bean.Product;
import com.cts.grizzly_store.service.CategoryService;
import com.cts.grizzly_store.service.LoginService;
import com.cts.grizzly_store.service.ProductService;



@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	@Autowired
	CategoryService categoryService;
	@Autowired
	LoginService loginService;
	
//	@RequestMapping("Admin-AddProduct.html")
//	public String getProductPage(){
//		return "Admin-AddProduct";
//	}
	@RequestMapping("Admin-AddProduct12.html")						//PostMapping(value="login.html", method= RequestMethod.GET)
	public ModelAndView addPage(@ModelAttribute Product product){
		ModelAndView modelAndView = new ModelAndView();
//		Login login2= loginService.authenticate(login.getUserId(), login.getPassword());
//		modelAndView.addObject("user", login2);
		modelAndView.addObject("category",categoryService.getAllCategory());
		modelAndView.setViewName("Admin-AddProduct");
		return modelAndView;
	}
	
	@RequestMapping("remove.html")
	public ModelAndView remove(@ModelAttribute Product product, @RequestParam("id") String productId)
	{
		ModelAndView modelAndView= new ModelAndView();
		String a=productService.deleteProduct(productId);
		if(a.equals("Success")){
			modelAndView.addObject("products", productService.getAllProduct());
		modelAndView.setViewName("Admin-ListProducts");
		}
		return modelAndView;
	}
	@RequestMapping("lowtohigh.html")
	public ModelAndView validateUser(@ModelAttribute Product product, @RequestParam("order") String order, HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
			List<Product> product1= productService.getAllProductbylowtohigh(order);
			modelAndView.addObject("products", product1);
			modelAndView.setViewName("Admin-ListProducts");
			return modelAndView;
		

	}
	
	
	@RequestMapping("lowtohigh1.html")
	public ModelAndView validateUser1(@ModelAttribute Product product, @RequestParam("order") String order, HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
			List<Product> product1= productService.getProductForVendor1(order);
			modelAndView.addObject("products", product1);
			modelAndView.setViewName("Vendor-AddProduct");
			return modelAndView;
		

	}
	
	
	@RequestMapping("viewproduct.html")
	public ModelAndView viewProduct(@ModelAttribute Product product, @RequestParam("id") String productId){
		ModelAndView modelAndView = new ModelAndView();
		Product product1=productService.getProductById(productId);
		modelAndView.addObject("product", product1);
		modelAndView.setViewName("Admin-ViewProduct");
		return modelAndView;
	}
	
	@RequestMapping(value="Admin-AddProduct.html", method= RequestMethod.POST)						//PostMapping(value="login.html", method= RequestMethod.GET)
	public ModelAndView insertProduct(@ModelAttribute Product product,HttpSession httpSession){
		ModelAndView modelAndView = new ModelAndView();
		
	
		productService.insertProduct(product);
			modelAndView.setViewName("Admin-ListProducts");
			modelAndView.addObject("products", productService.getAllProduct());
		return modelAndView;
	}
	
	@RequestMapping("inventory.html")
	public ModelAndView inventory(@ModelAttribute Product product)
	{
		ModelAndView modelAndView= new ModelAndView();
		modelAndView.setViewName("Vendor-Inventory");
		return modelAndView;
	}
	@RequestMapping("block.html")
	public ModelAndView block(@ModelAttribute Product product, @RequestParam("id") String productId)
	{
		ModelAndView modelAndView= new ModelAndView();
		String status=productService.getProductStatus(productId);
		if(productService.block(productId,status)){
		modelAndView.addObject("products", productService.getAllProduct());
		modelAndView.setViewName("Admin-ListProducts");
		}
		return modelAndView;
	}
	
	@RequestMapping("unblock.html")
	public ModelAndView unblock(@ModelAttribute Product product, @RequestParam("id") String productId)
	{
		ModelAndView modelAndView= new ModelAndView();
		String status=productService.getProductStatus(productId);
		if(productService.unblock(productId,status)){
		modelAndView.addObject("products", productService.getAllProduct());
		modelAndView.setViewName("Admin-ListProducts");
		}
		return modelAndView;
	}
	
	@RequestMapping("Vendor-AddProduct12.html")						//PostMapping(value="login.html", method= RequestMethod.GET)
	public ModelAndView addVendorPage(@ModelAttribute Product product){
		ModelAndView modelAndView = new ModelAndView();
//		Login login2= loginService.authenticate(login.getUserId(), login.getPassword());
//		modelAndView.addObject("user", login2);
		modelAndView.addObject("category",categoryService.getAllCategory());
		modelAndView.setViewName("Vendor-AddProduct2");
		return modelAndView;
	}
	
	@RequestMapping(value="Vendor-AddProduct.html", method= RequestMethod.POST)						//PostMapping(value="login.html", method= RequestMethod.GET)
	public ModelAndView insertVendorProduct(@ModelAttribute Product product){
		ModelAndView modelAndView = new ModelAndView();
		
	
		productService.insertProduct(product);
		
			modelAndView.setViewName("Vendor-AddProduct");
			modelAndView.addObject("products", productService.getProductForVendor());
		return modelAndView;
	}
	@RequestMapping("logout.html")
	public ModelAndView logout(HttpSession httpSession)
	{
		ModelAndView modelAndView = new ModelAndView();
		httpSession.invalidate();
		modelAndView.setViewName("login");
		return modelAndView;
		
	}
}
	
	

